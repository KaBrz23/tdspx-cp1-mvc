using Microsoft.AspNetCore.Mvc;

namespace tdspx_cp_mvc.Controllers;

public class ContactsController : Controller
{
    // GET
    public IActionResult Cliente()
    {
        ViewBag.textoCliente = "Cliente";
        return View();
    }
}