using Microsoft.AspNetCore.Mvc;

namespace tdspx_cp_mvc.Controllers;

public class ProdutoController : Controller
{
    // GET
    public IActionResult Produto()
    {
        ViewBag.textoProduto = "Produto";
        return View();
    }
}